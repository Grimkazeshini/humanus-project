# GodChain Phase 1

Deploy smart contracts and run the frontend on Sepolia.