const hre = require("hardhat");

async function main() {
  const [deployer] = await hre.ethers.getSigners();
  console.log("Deploying contracts with:", deployer.address);

  // Deploy GodToken contract
  const Token = await hre.ethers.getContractFactory("GodToken");
  const token = await Token.deploy();
  await token.waitForDeployment();
  console.log("GodToken deployed at:", token.target);

  // Deploy Staking contract with GodToken's address as a parameter
  const Staking = await hre.ethers.getContractFactory("Staking");
  const staking = await Staking.deploy(token.target);
  await staking.waitForDeployment();
  console.log("Staking deployed at:", staking.target);

  // Deploy Governance contract
  const Governance = await hre.ethers.getContractFactory("Governance");
  const governance = await Governance.deploy();
  await governance.waitForDeployment();
  console.log("Governance deployed at:", governance.target);

  // Deploy Identity contract
  const Identity = await hre.ethers.getContractFactory("Identity");
  const identity = await Identity.deploy();
  await identity.waitForDeployment();
  console.log("Identity deployed at:", identity.target);

  // Deploy AIDevInterface contract with GodToken's address as a parameter
  const AIDev = await hre.ethers.getContractFactory("AIDevInterface");
  const ai = await AIDev.deploy(token.target);
  await ai.waitForDeployment();
  console.log("AIDevInterface deployed at:", ai.target);
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
